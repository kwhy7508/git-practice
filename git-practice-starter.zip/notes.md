# Notes
- Make at least five commits.
- Try: edit `notes.md`, update `app.py`, add a new file, rename a file, etc.
- Use `git log` to see your history.

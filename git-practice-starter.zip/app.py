def main():
    print("Hello from git-practice!")
    print("Edit me and make more commits 🙂")

if __name__ == "__main__":
    main()
